<?php
class NewController extends CI_Controller
{
    public function Index()
    {
        $this->load->view('contoh1');
    }
}