<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Latihan 1</title>
</head>
<body>
    Nilai 1 = <?= $nilai1; ?>
    Nilai 2 = <?= $nilai2; ?>
    ini hasil dari pemodelan dengan methode penjumlahan yaitu 
    <?=$nilai1 ." + ". $nilai2 ." = ". $hasil; ?>
</body>
</html>